"use client";

import Link from "next/link";
import { useRouter,usePathname } from "next/navigation";
import Swal from "sweetalert2";
import axios from "axios";
import { config } from "./lib/config";
import { useEffect,useState,useCallback, useRef } from "react";
// import Modal from "./modal";
import Image from "next/image";
import ButtomSidebar from "@/app/components/ButtomSidebar";
import SubButtomSidebar from "@/app/components/SubButtonSidebar";
// import { Router } from "next/router";
// import { set } from "date-fns";
interface SidebarProps {
  className?: string;
}

export default function Sidebar({ className }: SidebarProps) {

  const currentPathname = usePathname(); // Get current pathname
  const [hoversidebar, setHoverSidebar] = useState(false);
  const [showLogoutTextWithDelay, setShowLogoutTextWithDelay] = useState(false);
  const logoutTextTimerRef = useRef<NodeJS.Timeout | null>(null);
  const LOGOUT_TEXT_DISPLAY_DELAY = 400; // 200ms delay
  const [level, setLevel] = useState("");
  const router = useRouter();
  const pathname = usePathname(); // ดึง URL ปัจจุบัน
  // const [isShow, setShowModal] = useState(false);
  // const [name, setName] = useState("");
  // const [username, setUsername] = useState("");

  const [countNotiUnread, setCountNotiUnread] = useState(0);
  // const [password, setPassword] = useState('');
  // const [confirmPassword, setConfirmPassword] = useState('');

  // const handleShowModal = () => {
  //     setShowModal(true);
  // }

  // const handleCloseModal = () => {
  //     setShowModal(false);
  // }

  // const windthsize = 30;
  // const heightsize = 30;

  useEffect(() => {

    fetchData1(); // เรียกและตรวจสอบข้อมูล user
    fetchData2(); // ตรวจสอบการแจ้งเตือนใหม่

    const token = localStorage.getItem("token");

    if (token) {

      if (pathname === "/backoffice/dashboard"
        || pathname === "/backoffice/promotions"
        || pathname === "/backoffice/shop"
        || pathname === "/backoffice/products"
        || pathname === "/backoffice/products/category"
        || pathname === "/backoffice/user"
        || pathname === "/backoffice/user/usergroup"
        || pathname === "/backoffice/report/order"
        || pathname === "/backoffice/report/user"
        || pathname === "/backoffice/event-log"
        || pathname === "/backoffice/notification"
      ) {

      } else {

        router.push("/backoffice/dashboard");
        
      }
    } else {

      localStorage.removeItem("token"); // ล้าง token เผื่อมีค่าเก่าที่ไม่ถูกต้อง
      router.push("/");

    }

    const interval1 = setInterval(() => {
      fetchData1(); // เรียกและตรวจสอบข้อมูล user
    }, 30000); // ตรวจสอบและอัปเดตทุก 30 วินาที

    const interval2 = setInterval(() => {
      fetchData2(); // ตรวจสอบข้อมูลการแจ้งเตือนใหม่
    }, 3000); // ตรวจสอบและอัปเดตทุก 3 วินาที

    return () => {
      clearInterval(interval1);
      clearInterval(interval2);
      if (logoutTextTimerRef.current) {
        clearTimeout(logoutTextTimerRef.current);
      }
    }; // ล้าง interval เมื่อ component ถูก unmount
  }, [router]);

  useEffect(() => {

    if (hoversidebar) {
      if (logoutTextTimerRef.current) {
        clearTimeout(logoutTextTimerRef.current);
      }
      logoutTextTimerRef.current = setTimeout(() => {
        setShowLogoutTextWithDelay(true);
      }, LOGOUT_TEXT_DISPLAY_DELAY);
    } else {
      if (logoutTextTimerRef.current) {
        clearTimeout(logoutTextTimerRef.current);
      }
      setShowLogoutTextWithDelay(false); // Hide immediately
    }

    return () => { // Cleanup on unmount or if hoversidebar changes
      if (logoutTextTimerRef.current) {
        clearTimeout(logoutTextTimerRef.current);
      }
    };
    
  }, [hoversidebar]);

  // เรียกและตรวจสอบข้อมูล user
  // Wrap fetchData1 in useCallback
  const fetchData1 = useCallback(async () => {
    
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        localStorage.removeItem("token");
        router.push("/");
      }

      const headers = {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        "X-API-KEY": config.apiKey,
      };

      await axios.get(`${config.apiUrl}/backoffice/checklogin`, {
        headers: headers,
      }).then((res) => {

        if (res.status == 200) {

          setLevel(res.data.level);

        } else if (res.status == 401) {

          Swal.fire({
            icon: "warning",
            title: "เข้าสู่ระบบ",
            text: 'กรุณาเข้าสู่ระบบใหม่อีกครั้ง',
            showCancelButton: true,
            timer: 1500
          });

          localStorage.removeItem("token");
          router.push("/");

        } else {

          localStorage.removeItem("token");
          router.push("/");

        }

      }).catch((err) => {

        Swal.fire({
          icon: "warning",
          title: "เข้าสู่ระบบ",
          text: 'กรุณาเข้าสู่ระบบใหม่อีกครั้ง',
          confirmButtonColor: "oxbowteal",
          timer: 1000
          // timer: 1500
        });

        console.error("Error fetching data:", err); // Log the error for debugging
        localStorage.removeItem("token");
        router.push("/");

      });
      
    } catch (error) {
      console.error("Error fetching data:", error); // Log the error for debugging
      // if (error.response && error.response.status === 401) {
      //   Swal.fire({
      //     icon: "warning",
      //     title: "เข้าสู่ระบบ",
      //     text: 'กรุณาเข้าสู่ระบบใหม่อีกครั้ง',
      //     showCancelButton: true
      //   }).then((result) => {

      //     localStorage.removeItem("token");
      //     router.push("/");

      //   });
      //   return;
      // }

      // Swal.fire({
      //   icon: "error",
      //   title: "เกิดข้อผิดพลาด",
      //   text: `${error}`,
      // });
    }
  }, []);

  // ตรวจสอบการแจ้งเตือนใหม่
  const fetchData2 = useCallback(async () => { // Wrap in useCallback
    try {
      const token = localStorage.getItem("token");

      if (!token) {
        // handleLogout(); // ฟังก์ชันสำหรับเคลียร์ค่าและเด้งไปหน้า Login
        return;
      }

      const headers = {
        "Content-Type": "application/json",
        Authorization: `Bearer ${token}`,
        "X-API-KEY": config.apiKey,
      };

      const res = await axios.get(
        `${config.apiUrl}/backoffice/notificationunreadcount`,
        {
          headers: headers,
        }
      );

      if (res.data) {
        setCountNotiUnread(res.data.unreadCount);
      }
    } catch (error) {

      console.error("Error fetching data:", error); // Log the error for debugging

      return;

      // Swal.fire({
      //   icon: "error",
      //   title: "เกิดข้อผิดพลาด",
      //   text: `${error}`,
      // });
    }
}, []); 

  const handleLogout = async() => {

    try {
      
      Swal.fire({
        title: "ออกจากระบบ",
        text: "คุณต้องการออกจากระบบหรือไม่?",
        icon: "warning",
        showCancelButton: true,
        confirmButtonColor: "#188875",
        cancelButtonColor: "#bdbdbd",
        confirmButtonText: "ใช่",
        cancelButtonText: "ยกเลิก",
      }).then(async (result) => {

        if (result.isConfirmed) {

          await axios.get(`${config.apiUrl}/backoffice/signout`, {
            headers: {
              "Content-Type": "application/json",
              "X-API-KEY": config.apiKey,
              Authorization: `Bearer ${localStorage.getItem("token")}`,
            },
          }).then(async(res) => {
    
            Swal.fire({
              icon: "success",
              title: "ออกจากระบบสำเร็จ",
              // text: `${res.data.message}`,
              showConfirmButton: false,
              timer: 1000,
            });
    
            if (res.status === 200) { // Use explicit if statement
              localStorage.removeItem("token");
            }
    
            router.push("/");
            return;

          });     
        }
      }).catch((err) => {
        Swal.fire({
          icon: "error",
          title: "เกิดข้อผิดพลาด",
          text: `${err}`,
        });

        if(localStorage.getItem("token")) localStorage.removeItem("token");
    
        router.push("/");
        return;
      })
       

    } catch (error) {
      
      Swal.fire({
        icon: "error",
        title: "เกิดข้อผิดพลาด",
        text: `${error}`,
      });

      if(localStorage.getItem("token")) localStorage.removeItem("token");

      router.push("/");
      return;
    }
    
  };

  return (
    <div
      className={`relative bg-oatmilk shadow-xl h-screen rounded-[16px] transition-all durationease-in-out duration-500 ${className} ${
        hoversidebar ? "w-[120px] xl:w-[200px]" : "w-[64px] xl:w-[100px]"
      }`}
      onMouseEnter={() => {
        setHoverSidebar(true);
      }}
      onMouseLeave={() => setHoverSidebar(false)}
    >

      <div className="absolute w-full top-0 flex justify-center items-center shadow-sm  z-50">

        <div className=" max-w-[100px] xl:max-w-[120px] h-[100px] xl:h-[120px] my-[4px] pl-[2px] xl:pl-[13px] px-[2px] xl:pr-[15px] xl:py-10 flex justify-center items-center">
          <Link href="/backoffice/dashboard">
            <Image
              src="/img/logobackoffice.png"
              width={150}
              height={120}
              alt="products"
              className="rounded-full"
            />
          </Link>
        </div>
      </div>
      {/* Logo */}

      <div className="pt-[150px]  pl-[2px] h-full xl:pl-[13px] flex-1 overflow-auto">

        <div className="flex flex-col justify-center items-center py-2">
          {/* <button className="absolute -top-[-20px] -right-[-40px]">
            <i className="text-xl fa-solid fa-bars"></i>
          </button> */}


            {/* Dashboard */}
            <ButtomSidebar
              label="Dashboard"
              status={currentPathname === "/backoffice/dashboard"}
              hoveraction={hoversidebar}
              urllink="/backoffice/dashboard"
              // onClick={async () => {
              //   resetStatus();
              //   setStatusDashboard(true);
              // }}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                viewBox="0 0 20 20"
                className={`${
                  currentPathname === "/backoffice/dashboard"
                    ? "fill-oatmilk"
                    : "fill-oxbowteal hover:fill-deepforest"
                }`}
              >
                <path d="M8.49776 4.7606C8.58545 4.93485 8.63817 5.12392 8.65332 5.32102L9.04185 10.8095C9.04706 10.8847 9.08269 10.9548 9.14085 11.0042C9.18448 11.0413 9.23808 11.0645 9.29801 11.0712L9.35991 11.0724L14.9341 10.7366C15.3867 10.71 15.8305 10.8675 16.1604 11.1719C16.4902 11.4763 16.6768 11.9004 16.6744 12.3912C16.4265 16.0037 13.773 19.0237 10.159 19.8065C6.54503 20.5893 2.83611 18.9474 1.05781 15.7848C0.582292 14.9695 0.261779 14.0778 0.113798 13.1749L0.0664268 12.8359C0.0253023 12.5821 0.00319023 12.3257 0 12.0795L0.00311369 11.8372C0.0133983 8.06546 2.66156 4.80403 6.38809 3.92434L6.64383 3.86807L6.7814 3.84532C7.502 3.74681 8.21097 4.12453 8.49776 4.7606ZM7.01643 5.27813L6.93217 5.28772L6.70369 5.33933C3.73526 6.05477 1.6062 8.61031 1.48796 11.621L1.4828 11.8661C1.47569 12.0525 1.4825 12.2392 1.50499 12.4378L1.53277 12.6408C1.63212 13.495 1.90795 14.3206 2.34914 15.0772C3.81632 17.6863 6.86669 19.0367 9.839 18.3929C12.8113 17.7491 14.9936 15.2653 15.1958 12.3414C15.1958 12.2974 15.1774 12.2552 15.1446 12.225C15.1228 12.2049 15.0959 12.1912 15.0675 12.1851L15.024 12.1817L9.45904 12.5169C8.98938 12.5503 8.52549 12.3992 8.17003 12.0971C7.81456 11.7951 7.59684 11.3669 7.56522 10.91L7.17702 5.42617C7.17632 5.41708 7.17385 5.40822 7.15682 5.37299C7.1315 5.31695 7.07648 5.28131 7.01643 5.27813ZM11.423 0.00105033C15.7084 0.122269 19.3029 3.20162 19.9904 7.34084L20 7.4567L19.9977 7.65855C19.9737 7.95621 19.8538 8.23931 19.6545 8.46677C19.4041 8.75241 19.0477 8.92862 18.6588 8.95674L12.0133 9.39005C11.1615 9.43818 10.4295 8.80509 10.3741 7.97348L9.92986 1.44914L9.9349 1.30295L9.95698 1.13824C10.0162 0.84619 10.1684 0.579378 10.3925 0.376428C10.6739 0.121564 11.0474 -0.0133911 11.423 0.00105033ZM11.4113 1.44902L11.8511 7.87814C11.8537 7.91719 11.888 7.94688 11.9214 7.94502L18.5182 7.51352L18.4854 7.33352C17.8318 4.0802 15.0119 1.66443 11.6287 1.45932L11.4113 1.44902Z" />
              </svg>
            </ButtomSidebar>

            {/* Promotions */}
            {level !== "Admin" ? (
              <ButtomSidebar
                label="โปรโมชั่น"
                status={currentPathname === "/backoffice/promotions"}
                hoveraction={hoversidebar}
                urllink="/backoffice/promotions"
                // onClick={async () => {
                //   resetStatus();
                //   setStatusPromotions(true);
                // }}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  className={` ${
                    currentPathname === "/backoffice/promotions"
                      ? "fill-oatmilk"
                      : "fill-oxbowteal hover:fill-deepforest"
                  }`}
                >
                  <path d="M11.951 0.716446L12.1333 0.886452L12.8521 1.6052C13.0989 1.85092 13.4228 2.00242 13.7673 2.03646L13.916 2.04378H14.944C16.5478 2.04378 17.8592 3.29795 17.9509 4.87883L17.956 5.05578V6.08278C17.956 6.43258 18.0766 6.76886 18.2942 7.03624L18.3933 7.14645L19.1121 7.86525C20.2436 8.99165 20.2942 10.7929 19.2576 11.98L19.1223 12.1251L18.3939 12.8535C18.149 13.099 17.9974 13.4231 17.9633 13.7672L17.956 13.9158V14.9448C17.956 16.5485 16.7019 17.8591 15.1209 17.9507L14.944 17.9558H13.916C13.5674 17.9558 13.2307 18.0769 12.9632 18.2951L12.8529 18.3945L12.1351 19.1113C11.0099 20.2442 9.20732 20.2944 8.0198 19.2574L7.86565 19.1131L7.14854 18.396C6.90014 18.1494 6.57571 17.9973 6.2322 17.9631L6.08398 17.9558H5.05498C3.45185 17.9558 2.1407 16.7023 2.0491 15.1217L2.04398 14.9448V13.9158C2.04398 13.5678 1.92268 13.2308 1.7046 12.9637L1.60528 12.8537L0.888155 12.1356C-0.24442 11.0094 -0.294658 9.20679 0.742362 8.02044L0.877652 7.87545L1.60377 7.14834C1.85072 6.89963 2.00255 6.57581 2.03664 6.23146L2.04398 6.08278V5.05578L2.0491 4.87885C2.13732 3.35668 3.35648 2.13715 4.87811 2.0489L5.05498 2.04378H6.08398C6.43246 2.04378 6.76923 1.9229 7.03628 1.70572L7.14628 1.60682L7.86445 0.887655C8.99082 -0.243823 10.7932 -0.293637 11.951 0.716446ZM9.0414 1.84256L8.92668 1.94674L8.20543 2.66899C7.68818 3.18258 7.00406 3.48966 6.28181 3.53727L6.08398 3.54378H5.05498C4.26742 3.54378 3.6197 4.14793 3.55016 4.91821L3.54398 5.05578V6.08278C3.54398 6.81195 3.27937 7.5131 2.80208 8.06116L2.66668 8.20674L1.93951 8.93491C1.3877 9.48923 1.35557 10.3649 1.84322 10.9589L1.94768 11.0738L2.66694 11.7941C3.18134 12.3097 3.48963 12.995 3.53744 13.7178L3.54398 13.9158V14.9448C3.54398 15.7328 4.14769 16.3801 4.9175 16.4496L5.05498 16.4558H6.08398C6.81177 16.4558 7.51353 16.7207 8.06171 17.198L8.20731 17.3335L8.93062 18.0568C9.48884 18.6119 10.3647 18.6442 10.9583 18.1565L11.073 18.0521L11.7939 17.3322C12.3106 16.8179 12.9951 16.5101 13.718 16.4623L13.916 16.4558H14.944C15.7327 16.4558 16.3803 15.8524 16.4498 15.0823L16.456 14.9448V13.9158C16.456 13.1869 16.7208 12.4839 17.1974 11.9383L17.3327 11.7935L18.0602 11.066C18.612 10.511 18.6439 9.63577 18.157 9.04195L18.0527 8.92711L17.3308 8.20523C16.8169 7.68765 16.5101 7.00422 16.4625 6.28094L16.456 6.08278V5.05578C16.456 4.26737 15.8519 3.61951 15.0816 3.54996L14.944 3.54378H13.916C13.1868 3.54378 12.4848 3.27939 11.9379 2.80243L11.7927 2.66711L11.1047 1.97734L11.0649 1.94031C10.5106 1.38855 9.63472 1.35624 9.0414 1.84256ZM13.0964 12.0424C13.1664 12.1124 13.2264 12.1924 13.2664 12.2824C13.2964 12.3724 13.3164 12.4724 13.3164 12.5724C13.3164 12.6734 13.2964 12.7624 13.2664 12.8524C13.2264 12.9424 13.1664 13.0324 13.0964 13.1024C12.9564 13.2424 12.7664 13.3224 12.5664 13.3224C12.3664 13.3224 12.1764 13.2424 12.0364 13.1024C11.9664 13.0324 11.9164 12.9424 11.8764 12.8524C11.8364 12.7624 11.8164 12.6734 11.8164 12.5724C11.8164 12.4724 11.8364 12.3724 11.8764 12.2824C11.9164 12.1924 11.9664 12.1124 12.0364 12.0424C12.3164 11.7624 12.8164 11.7624 13.0964 12.0424ZM13.1 6.89915C13.3663 7.16542 13.3905 7.58208 13.1726 7.87569L13.1 7.95981L7.96001 13.0998C7.66712 13.3927 7.19225 13.3927 6.89935 13.0998C6.63309 12.8335 6.60888 12.4169 6.82673 12.1233L6.89935 12.0392L12.0394 6.89915C12.3322 6.60626 12.8071 6.60626 13.1 6.89915ZM7.95628 6.90278C8.09628 7.04178 8.17628 7.23278 8.17628 7.43278C8.17628 7.53278 8.16628 7.62178 8.12628 7.71278C8.08628 7.80278 8.02628 7.88278 7.95628 7.96278C7.88628 8.03278 7.80628 8.08178 7.71628 8.12178C7.62628 8.16178 7.52628 8.18278 7.42628 8.18278C7.32628 8.18278 7.23628 8.16178 7.14628 8.12178C7.05628 8.08178 6.96628 8.03278 6.89628 7.96278C6.82628 7.88278 6.77628 7.80278 6.73628 7.71278C6.69628 7.62178 6.67628 7.53278 6.67628 7.43278C6.67628 7.33178 6.69628 7.23278 6.73628 7.14278C6.77628 7.05278 6.82628 6.96278 6.89628 6.90278C7.18628 6.62178 7.67628 6.62178 7.95628 6.90278Z" />
                </svg>
              </ButtomSidebar>
            ) : null}

            {/* Shop */}
            {level === "Admin" || level === "Owner" ? (
              <ButtomSidebar
                label="ร้านค้า"
                status={currentPathname === "/backoffice/shop"}
                hoveraction={hoversidebar}
                urllink="/backoffice/shop"
                // onClick={async () => {
                //   resetStatus();
                //   setStatusShop(true);
                // }}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 22 20"
                  className={` ${
                    currentPathname === "/backoffice/shop"
                      ? "fill-oxbowteal"
                      : "fill-oatmilk"
                  } stroke-[2] ${
                    currentPathname === "/backoffice/shop"
                      ? "stroke-oatmilk"
                      : "stroke-oxbowteal hover:stroke-deepforest"
                  } stroke-linecap-round stroke-linejoin-round`}
                >
                  <path d="M1 5L4 1H16L19 5M1 5V19C1 19.5304 1.21071 20.0391 1.58579 20.4142C1.96086 20.7893 2.46957 21 3 21H17C17.5304 21 18.0391 20.7893 18.4142 20.4142C18.7893 20.0391 19 19.5304 19 19V5M1 5H19M14 9C14 10.0609 13.5786 11.0783 12.8284 11.8284C12.0783 12.5786 11.0609 13 10 13C8.93913 13 7.92172 12.5786 7.17157 11.8284C6.42143 11.0783 6 10.0609 6 9" />
                </svg>
              </ButtomSidebar>
            ) : null}

            {/* Product */}
            {level !== "Admin" ? (
              <ButtomSidebar
                label="สินค้า"
                status={currentPathname === "/backoffice/products"}
                hoveraction={hoversidebar}
                urllink="/backoffice/products"
                // onClick={async () => {
                //   resetStatus();
                //   setStatusProduct(true);
                // }}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 20"
                  className={` ${
                    currentPathname === "/backoffice/products"
                      ? "fill-oatmilk"
                      : "fill-oxbowteal hover:fill-deepforest"
                  }`}
                >
                  <path d="M3.75 12.1875H8.8125V13.875H3.75V12.1875ZM3.75 15.5625H12.1875V17.25H3.75V15.5625Z" />
                  <path d="M18.9375 0.375H2.0625C1.61515 0.37567 1.18632 0.553674 0.869997 0.869997C0.553674 1.18632 0.37567 1.61515 0.375 2.0625V18.9375C0.37567 19.3848 0.553674 19.8137 0.869997 20.13C1.18632 20.4463 1.61515 20.6243 2.0625 20.625H18.9375C19.3848 20.6243 19.8137 20.4463 20.13 20.13C20.4463 19.8137 20.6243 19.3848 20.625 18.9375V2.0625C20.6243 1.61515 20.4463 1.18632 20.13 0.869997C19.8137 0.553674 19.3848 0.37567 18.9375 0.375ZM12.1875 2.0625V5.4375H8.8125V2.0625H12.1875ZM2.0625 18.9375V2.0625H7.125V7.125H13.875V2.0625H18.9375L18.9383 18.9375H2.0625Z" />
                </svg>
              </ButtomSidebar>
            ) : null}

            {/* User */}
            {level === "Admin" || level === "Owner" || level === "Manager" ? (
              <ButtomSidebar
                label="บัญชีผู้ใช้"
                status={currentPathname === "/backoffice/user"}
                hoveraction={hoversidebar}
                urllink="/backoffice/user"
                // onClick={async () => {
                //   resetStatus();
                //   setStatusUser(true);
                // }}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 24 22"
                  className={`
                    w-8 h-4 xl:w-8 xl:h-6
                    ${
                      currentPathname === "/backoffice/user"
                        ? "stroke-oatmilk"
                        : "stroke-oxbowteal hover:stroke-deepforest"
                    }
                    stroke-[2] stroke-linecap-round stroke-linejoin-round
                    `}
                >
                  {/* <path d="M8.83298 1.79183C7.27623 1.79183 6.03798 3.01708 6.03798 4.50016C6.03798 5.98325 7.27731 7.2085 8.83298 7.2085C10.3886 7.2085 11.6269 5.98325 11.6269 4.50016C11.6269 3.01708 10.3886 1.79183 8.8319 1.79183M4.95465 4.50016C4.95465 2.39308 6.70423 0.708496 8.83298 0.708496C10.9606 0.708496 12.7102 2.39308 12.7102 4.50016C12.7102 6.60725 10.9606 8.29183 8.8319 8.29183C6.70531 8.29183 4.95681 6.60725 4.95681 4.50016M6.24165 10.7358C6.00548 10.5842 5.77581 10.5408 5.6079 10.5863C5.44901 10.6297 5.29048 10.6766 5.13231 10.7272L4.06631 11.0695C3.6611 11.1947 3.29063 11.4127 2.98431 11.706C2.67798 11.9994 2.44422 12.3601 2.30156 12.7595C2.26906 12.857 2.2474 12.9697 2.23223 13.1137L1.80973 17.1167L1.80865 17.1264C1.71115 17.8154 2.08165 18.3993 2.70131 18.5434C3.88973 18.8186 5.87548 19.1252 8.83515 19.1252C8.97881 19.1252 9.11658 19.1822 9.21816 19.2838C9.31975 19.3854 9.37681 19.5232 9.37681 19.6668C9.37681 19.8105 9.31975 19.9483 9.21816 20.0498C9.11658 20.1514 8.97881 20.2085 8.83515 20.2085C5.80181 20.2085 3.73265 19.8943 2.45648 19.5986C1.2139 19.3104 0.574731 18.1415 0.733981 16.9834L1.1554 13C1.17381 12.8223 1.20523 12.6154 1.27781 12.4052C1.47554 11.8469 1.80063 11.3423 2.2273 10.9314C2.65397 10.5205 3.17048 10.2147 3.7359 10.0382L4.8019 9.69583C4.97379 9.64094 5.1464 9.58966 5.31973 9.542C5.88306 9.38708 6.4334 9.57016 6.8299 9.82691C7.25673 10.1021 7.96198 10.4433 8.83407 10.4433C9.70615 10.4433 10.4125 10.1021 10.8393 9.82583C11.2369 9.57016 11.7861 9.38708 12.3495 9.542C12.5228 9.59039 12.6954 9.64166 12.8673 9.69583L13.9344 10.0382C14.0038 10.0584 14.0685 10.0924 14.1245 10.1381C14.1806 10.1837 14.227 10.2401 14.2609 10.304C14.2948 10.3679 14.3156 10.4379 14.3221 10.5099C14.3285 10.5819 14.3205 10.6545 14.2984 10.7234C14.2763 10.7922 14.2407 10.856 14.1936 10.9109C14.1465 10.9657 14.0889 11.0106 14.0242 11.0429C13.9595 11.0752 13.8889 11.0941 13.8168 11.0987C13.7446 11.1033 13.6723 11.0933 13.604 11.0695L12.5369 10.7282C12.3802 10.6777 12.222 10.6307 12.0624 10.5874C11.8934 10.5408 11.6648 10.5831 11.4276 10.7358C10.8978 11.0792 9.98781 11.5267 8.83515 11.5267C7.6814 11.5267 6.7714 11.0792 6.24165 10.7358Z" 
                              />
                              <path d="M14.943 12.2568C14.9619 12.0603 15.0537 11.878 15.2002 11.7457C15.3467 11.6134 15.5375 11.5406 15.7349 11.5418H17.0966C17.2943 11.5404 17.4853 11.613 17.632 11.7453C17.7788 11.8776 17.8707 12.0601 17.8896 12.2568C17.9091 12.4811 18.0814 12.7205 18.3912 12.8787C18.4519 12.9097 18.5122 12.9422 18.5721 12.9762C18.9123 13.1712 19.2449 13.2069 19.4854 13.0997C19.6629 13.0196 19.8635 13.0069 20.0497 13.0639C20.2359 13.1209 20.395 13.2438 20.4972 13.4095L21.1776 14.5275C21.2822 14.6996 21.3158 14.9056 21.2711 15.102C21.2264 15.2984 21.107 15.4696 20.9381 15.5794C20.7431 15.7072 20.6099 15.9889 20.6142 16.3648V16.4688C20.6088 16.8447 20.7442 17.1264 20.9381 17.2542C21.107 17.3641 21.2264 17.5353 21.2711 17.7317C21.3158 17.928 21.2822 18.1341 21.1776 18.3062L20.4972 19.4242C20.395 19.5899 20.2359 19.7127 20.0497 19.7697C19.8635 19.8268 19.6629 19.8141 19.4854 19.734C19.2449 19.6267 18.9123 19.6625 18.5721 19.8575C18.5129 19.8907 18.4526 19.9232 18.3912 19.955C18.0814 20.1132 17.9091 20.3526 17.8896 20.5768C17.8707 20.7735 17.7788 20.956 17.632 21.0884C17.4853 21.2207 17.2943 21.2933 17.0966 21.2918H15.7338C15.5364 21.293 15.3457 21.2203 15.1991 21.088C15.0526 20.9557 14.9608 20.7733 14.9419 20.5768C14.9213 20.3526 14.7491 20.1132 14.4392 19.955C14.3785 19.9239 14.3186 19.8914 14.2594 19.8575C13.9181 19.6625 13.5856 19.6267 13.3451 19.734C13.1675 19.8141 12.967 19.8268 12.7808 19.7697C12.5946 19.7127 12.4355 19.5899 12.3332 19.4242L11.6529 18.3062C11.5483 18.134 11.5149 17.9278 11.5598 17.7314C11.6047 17.535 11.7244 17.3639 11.8934 17.2542C12.0884 17.1264 12.2216 16.8447 12.2162 16.4688V16.3648C12.2216 15.9889 12.0873 15.7072 11.8934 15.5794C11.7244 15.4698 11.6047 15.2986 11.5598 15.1022C11.5149 14.9058 11.5483 14.6997 11.6529 14.5275L12.3332 13.4095C12.4355 13.2438 12.5946 13.1209 12.7808 13.0639C12.967 13.0069 13.1675 13.0196 13.3451 13.0997C13.5856 13.2069 13.9192 13.1712 14.2594 12.9762C14.3186 12.9429 14.3786 12.9104 14.4392 12.8787C14.7491 12.7205 14.9213 12.4811 14.9419 12.2568M15.9732 12.6252C15.8237 13.195 15.3871 13.6121 14.9311 13.8439L14.7967 13.9165C14.3374 14.1797 13.7307 14.3444 13.1371 14.1732L12.72 14.8579C13.1544 15.2717 13.3061 15.8697 13.2996 16.3789V16.4547C13.3061 16.9639 13.1544 17.5619 12.72 17.9757L13.1371 18.6604C13.7307 18.4892 14.3374 18.6539 14.7967 18.9172C14.8401 18.9417 14.8848 18.9659 14.9311 18.9897C15.3861 19.2216 15.8237 19.6397 15.9732 20.2085H16.8561C17.0056 19.6387 17.4433 19.2216 17.8983 18.9897L18.0326 18.9172C18.492 18.6539 19.0997 18.4892 19.6934 18.6604L20.1094 17.9757C19.675 17.5619 19.5233 16.9639 19.5298 16.4547V16.3789C19.5233 15.8697 19.675 15.2717 20.1094 14.8579L19.6934 14.1732C19.0986 14.3444 18.492 14.1797 18.0326 13.9165L17.8983 13.8439C17.4433 13.6121 17.0056 13.1939 16.8561 12.6252H15.9732ZM17.2721 15.9759C17.0078 15.5426 16.399 15.3747 15.9126 15.6401C15.4424 15.899 15.3059 16.4417 15.5572 16.8577C15.8216 17.2911 16.4304 17.459 16.9168 17.1936C17.387 16.9347 17.5235 16.3919 17.2721 15.9759ZM15.3926 14.6911C16.3643 14.1592 17.6188 14.4636 18.1973 15.4126C18.7866 16.38 18.4237 17.6031 17.4368 18.1426C16.4651 18.6745 15.2106 18.3701 14.6321 17.4211C14.0438 16.4537 14.4056 15.2306 15.3926 14.6911Z" 
                              /> */}
                  <path
                    d="M5 20V19C5 16.2386 7.23858 14 10 14H14C16.7614 14 19 16.2386 19 19V20M16 7C16 9.20914 14.2091 11 12 11C9.79086 11 8 9.20914 8 7C8 4.79086 9.79086 3 12 3C14.2091 3 16 4.79086 16 7Z"
                    fill="transparent"
                  />
                </svg>
              </ButtomSidebar>
            ) : null}

            {/* Report */}
            {level === "Employee" || level === "Owner" || level === "Manager" || level === "Admin" ? (
              <SubButtomSidebar
                data={[
                  {
                    label: "รายงานการสั่งซื้อ",
                    urllink: "/backoffice/report/order",
                  },
                  {
                    label: "รายงานบัญชีผู้ใช้",
                    urllink: "/backoffice/report/user",
                  },
                ]}
                label="รายงาน"
                status={
                  currentPathname === "/backoffice/report/order" ||
                  currentPathname === "/backoffice/report/user"
                }
                hoveraction={hoversidebar}
                urllink="/backoffice/report/"
                // onClick={async () => {
                //   if(currentPathname !== "/backoffice/report/order" && currentPathname !== "/backoffice/report/user"){

                //     router.push("/backoffice/report/order");
                //   }
                // }}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 25 20"
                  className={` stroke-[2] fill-transparent ${
                    currentPathname === "/backoffice/report/order" ||
                    currentPathname === "/backoffice/report/user"
                      ? "stroke-oatmilk"
                      : "stroke-oxbowteal hover:stroke-deepforest"
                  } stroke-linecap-round stroke-linejoin-round`}
                >
                  {/* <path d="M16.5 21V2.5C16.5 2.10218 16.342 1.72064 16.0607 1.43934C15.7794 1.15804 15.3978 1 15 1H3C2.60218 1 2.22064 1.15804 1.93934 1.43934C1.65804 1.72064 1.5 2.10218 1.5 2.5V19.5C1.5 19.8978 1.65804 20.2794 1.93934 20.5607C2.22064 20.842 2.60218 21 3 21H16.5ZM16.5 21H19C19.3978 21 19.7794 20.842 20.0607 20.5607C20.342 20.2794 20.5 19.8978 20.5 19.5V11C20.5 10.7348 20.3946 10.4804 20.2071 10.2929C20.0196 10.1054 19.7652 10 19.5 10H17.5C17.2348 10 16.9804 10.1054 16.7929 10.2929C16.6054 10.4804 16.5 10.7348 16.5 11V21ZM4.5 5H8.5M4.5 8.5H10.5" 
                  /> */}

                  <path d="M13.5 3H12H8C6.34315 3 5 4.34315 5 6V18C5 19.6569 6.34315 21 8 21H16C17.6569 21 19 19.6569 19 18V8.625M13.5 3L19 8.625M13.5 3V7.625C13.5 8.17728 13.9477 8.625 14.5 8.625H19" />
                  <path d="M9 13H15" />
                  <path d="M9 17H15" />
                </svg>
              </SubButtomSidebar>
            ) : null}

            {/* Event log */}
            {level === "Admin" || level === "Owner" || level === "Manager" ? (
              <ButtomSidebar
                label="ดำเนินการ"
                status={currentPathname === "/backoffice/event-log"}
                hoveraction={hoversidebar}
                urllink="/backoffice/event-log"
                // onClick={async () => {
                //   resetStatus();
                //   setStatusEventlog(true);
                // }}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 25 20"
                  className={`${
                    currentPathname === "/backoffice/event-log"
                      ? "stroke-oatmilk"
                      : "stroke-oxbowteal hover:stroke-deepforest"
                  } fill-transparent stroke-[2px] stroke-linecap-round stroke-linejoin-round`}
                >
                  <path d="M1 10L3 12L5 10M12 5V10L15 13M12 19C16.9706 19 21 14.9706 21 10C21 5.02944 16.9706 1 12 1C7.02944 1 3 5.02944 3 10C3 9.96296 3 11 3 11" />
                </svg>
              </ButtomSidebar>
            ) : null}

            {/* notification */}
            {level === "Owner" || level === "Manager" || level === "Employee" ? (
              <ButtomSidebar
                label="แจ้งเตือน"
                status={currentPathname === "/backoffice/notification"}
                hoveraction={hoversidebar}
                urllink="/backoffice/notification"
                // onClick={async () => {
                //   resetStatus();
                //   setStatusNotification(true);
                // }}
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 18 20 "
                  className={`${
                    currentPathname === "/backoffice/notification"
                      ? "fill-oatmilk"
                      : "fill-oxbowteal hover:fill-deepforest"
                  }`}
                >
                  <path d="M11.608 17.6906C11.9045 17.9321 11.9515 18.3713 11.7129 18.6715C11.5366 18.8935 11.3327 19.0922 11.1167 19.255C10.3891 19.826 9.46401 20.0849 8.5453 19.9754C7.62578 19.8659 6.787 19.3962 6.21459 18.6689C5.9774 18.3676 6.02646 17.9286 6.32418 17.6885C6.62189 17.4484 7.05551 17.4981 7.29271 17.7995C7.63792 18.2381 8.14669 18.523 8.7064 18.5896C9.26691 18.6564 9.83075 18.4986 10.2826 18.1443C10.4158 18.0437 10.5355 17.927 10.6389 17.7969C10.8775 17.4967 11.3114 17.4491 11.608 17.6906ZM2.15213 6.99974L2.16444 6.40391C2.17324 6.14906 2.18686 5.91248 2.20685 5.68096C2.50654 2.44456 5.59565 0 8.96479 0H9.03612C12.4034 0 15.4934 2.44285 15.8034 5.68536C15.8212 5.89148 15.8288 6.07458 15.8311 6.33206L15.832 7.11982C15.8327 7.19158 15.8339 7.25469 15.8358 7.31353L15.845 7.50977L15.8896 7.69688C16.0303 8.21802 16.2776 8.70525 16.6162 9.12821L16.7669 9.30546L16.8286 9.38467C17.2348 9.99168 17.4668 10.698 17.5 11.4587L17.499 11.862C17.4707 12.763 17.1399 13.6331 16.5338 14.3582C15.7311 15.2101 14.6434 15.7393 13.4873 15.8457C10.502 16.1699 7.49 16.1699 4.51296 15.8466C3.34896 15.7346 2.26444 15.2069 1.42663 14.3223C0.808819 13.5691 0.480415 12.6208 0.500904 11.6624L0.50175 11.4242C0.537443 10.6955 0.768036 9.98985 1.16936 9.3802L1.23653 9.29378C1.70525 8.77993 2.02569 8.15105 2.16473 7.47306L2.14969 7.53395L2.15213 6.99974ZM9.03612 1.39535H8.96479C6.26651 1.39535 3.80804 3.34087 3.57967 5.80678C3.56798 5.94228 3.55866 6.08207 3.55137 6.2292L3.53532 6.69559L3.52879 7.61486L3.51441 7.75667C3.32444 8.68301 2.88728 9.54093 2.24929 10.2404L2.29856 10.1833L2.21045 10.3291C2.04539 10.6265 1.9389 10.9495 1.89682 11.2682L1.87935 11.4587L1.87919 11.6774C1.86568 12.3142 2.08086 12.9356 2.45369 13.3931C3.02881 13.9985 3.80682 14.377 4.65168 14.4583C7.53928 14.7719 10.4527 14.7719 13.3514 14.4572C14.1871 14.3802 14.9645 14.002 15.5084 13.4267C15.92 12.933 16.1375 12.3097 16.1216 11.6536L16.1224 11.4901C16.1013 11.0186 15.951 10.5613 15.6873 10.1672L15.7026 10.1926L15.5647 10.0309C15.0893 9.44409 14.744 8.76351 14.5517 8.03396L14.4868 7.75818L14.4739 7.66551C14.4642 7.53013 14.4585 7.40982 14.4555 7.26514L14.4528 6.3605C14.4509 6.13044 14.4447 5.97558 14.4307 5.81326C14.1944 3.34075 11.7336 1.39535 9.03612 1.39535Z" />
                </svg>
                {!(currentPathname === "/backoffice/notification") &&
                  countNotiUnread > 0 && (
                    <>
                      <div
                        className="
                          inline-flex
                          absolute 
                          top-[8px] left-[34px] xl:top-[14px] xl:left-[50px] 
                          bg-red-600 
                          shadow-lg
                          rounded-full 
                          animate-ping
                          w-[6px] h-[6px] xl:w-[10px] xl:h-[10px] 
                          z-20"
                      ></div>
                      <div
                        className="
                          inline-flex
                          absolute 
                          top-[8px] left-[34px] xl:top-[14px] xl:left-[50px] 
                          bg-red-600 
                          shadow-lg
                          rounded-full 
                          w-[6px] h-[6px] xl:w-[10px] xl:h-[10px] 
                          z-20"
                      ></div>
                    </>
                  )}
              </ButtomSidebar>
            ) : null}

            {/* <div className="w-full absolute bottom-10 xl:bottom-6 bg-oatmilk flex justify-start items-center pl-[20px] xl:pl-2  "> */}
            <div className="w-full xl:bottom-6 bg-oatmilk flex justify-start items-center pl-[20px] xl:pl-2  ">

              <button
                className="flex flex-row hover:bg-hoverteal xl:p-4 rounded-lg"
                onClick={handleLogout}
              >
                {/* <Image width={70} height={70} src="/img/logout.png" alt="logout" /> */}
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  viewBox="0 0 20 19"
                  className={` fill-oxbowteal hover:fill-deepforest`}
                >
                  <path d="M9.33146 0.0214844C11.7107 0.0214844 13.6526 1.89542 13.7616 4.24772L13.7665 4.45648V5.38948C13.7665 5.8037 13.4307 6.13948 13.0165 6.13948C12.6368 6.13948 12.323 5.85733 12.2733 5.49125L12.2665 5.38948V4.45648C12.2665 2.89358 11.0444 1.61575 9.5039 1.52647L9.33146 1.52148H4.45646C2.89441 1.52148 1.61671 2.74362 1.52744 4.28406L1.52246 4.45648V15.5865C1.52246 17.1493 2.74436 18.4272 4.28412 18.5165L4.45646 18.5215H9.34146C10.8988 18.5215 12.1725 17.3039 12.2615 15.7693L12.2665 15.5975V14.6545C12.2665 14.2403 12.6022 13.9045 13.0165 13.9045C13.3962 13.9045 13.71 14.1866 13.7596 14.5527L13.7665 14.6545V15.5975C13.7665 17.9687 11.8997 19.9046 9.55581 20.0164L9.34146 20.0215H4.45646C2.07802 20.0215 0.136302 18.1474 0.0272881 15.7952L0.0224609 15.5865V4.45648C0.0224609 2.07743 1.89622 0.135347 4.24777 0.0263125L4.45646 0.0214844H9.33146ZM17.3265 6.50234L17.4108 6.57478L20.3388 9.48978C20.3652 9.51594 20.3883 9.54256 20.4095 9.57073L20.3388 9.48978C20.3694 9.52019 20.3967 9.55258 20.421 9.58653C20.4381 9.61028 20.4538 9.63538 20.4681 9.66142C20.4707 9.66648 20.4733 9.67145 20.4759 9.67645C20.4886 9.70042 20.4998 9.72529 20.5097 9.75084C20.5137 9.76202 20.5178 9.77334 20.5216 9.78473C20.5289 9.80575 20.535 9.8274 20.5402 9.84942C20.5426 9.86118 20.545 9.87286 20.5472 9.88457C20.5513 9.90501 20.5543 9.9261 20.5564 9.94745C20.5575 9.96231 20.5585 9.97701 20.5591 9.99174C20.5598 10.0016 20.56 10.0115 20.56 10.0214L20.5591 10.0497C20.5585 10.0651 20.5575 10.0805 20.556 10.0958L20.56 10.0214C20.56 10.0682 20.5557 10.1141 20.5475 10.1585C20.545 10.1696 20.5426 10.1814 20.5398 10.193C20.5348 10.2162 20.5284 10.2387 20.521 10.2607C20.5172 10.2709 20.5135 10.2813 20.5095 10.2915C20.5002 10.3164 20.4894 10.3405 20.4774 10.3639C20.4744 10.3692 20.4712 10.3751 20.468 10.381C20.4336 10.4443 20.3905 10.5015 20.3403 10.5517L20.3389 10.5527L17.4109 13.4687C17.1174 13.761 16.6425 13.76 16.3502 13.4665C16.0845 13.1997 16.0612 12.783 16.2796 12.4898L16.3524 12.4059L17.9915 10.7705L7.76896 10.7714C7.35475 10.7714 7.01896 10.4356 7.01896 10.0214C7.01896 9.64169 7.30112 9.32789 7.66719 9.27823L7.76896 9.27139L17.9935 9.27048L16.3525 7.63779C16.0857 7.37212 16.0605 6.95551 16.2777 6.66142L16.3502 6.57714C16.6158 6.31028 17.0324 6.28514 17.3265 6.50234Z" />
                </svg>
                {showLogoutTextWithDelay ? (
                  <p
                    className={`ml-2 xl:ml-4 font-semibold text-[10px] xl:text-sm ${
                      "text-oxbowteal" // Removed 'status' as it's not defined here. Defaulting to the non-active color.
                    }`}
                  >
                    ออกจากระบบ
                  </p>
                ) : null}
              </button>
            </div>

          </div>
          
        </div>


        {/* sign out */}

      {/* <Modal title="แก้ไขข้อมูลผู้ใช้งาน" isOpen={isShow} onClose={handleCloseModal}>
                <div>
                    <div>ชื่อผู้ใช้งาน</div>
                    <input type="text" value={name}
                        onChange={(e) => setName(e.target.value)} className="form-control" />

                    <div className="mt-3">username</div>
                    <input type="text" value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        className="form-control" />

                    <div className="mt-3">รหัสผ่าน</div>
                    <input type="text"
                        onChange={(e) => setPassword(e.target.value)}
                        className="form-control" />

                    <div className="mt-3">ยืนยันรหัสผ่าน</div>
                    <input type="text"
                        onChange={(e) => setConfirmPassword(e.target.value)}
                        className="form-control" />

                    <div className="mt-3">
                        <button className="btn" onClick={handleSave}>
                            <i className="fa fa-save mr-2"></i>
                            บันทึก
                        </button>
                    </div>
                </div>
            </Modal> */}
    </div>
  );
}